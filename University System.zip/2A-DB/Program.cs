﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.Remoting.Contexts;
using System.Net.Sockets;

namespace Universidad
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.ForegroundColor = ConsoleColor.White;

            Alumnos conexion = new Alumnos();
            Maestros conexion_m = new Maestros();
            Carrera conexion_c = new Carrera();
            DataTable dt = new DataTable();

            string names, surnames, surnames2, cedula, des;
            int age, tuition, nEmpleado, idCarrera;
            int op1 = 0;
            int op1_ex = 4;

            while (op1 != op1_ex)
            {
                Console.Clear();
                Console.Write("   || Menú Principal ||\n\n1. Alumnos\n2. Maestros\n3. Carrera\n4. Salir\n\nSeleccione un opción > ");
                op1 = Convert.ToInt32(Console.ReadLine());
                if (op1 == 1)
                {
                    int operation = 0;
                    int closeExecution = 6;
                    while (operation != closeExecution)
                    {
                        Console.Clear();
                        Console.WriteLine("   || Menú Alumnos ||\n\n1. Registrar Alumno\n2. Eliminar Alumno\n3. Actualizar datos del Alumno\n4. Consulta general\n5. Consulta Individual (Requiere matrícula)\n6. Finalizar\n\nSeleccione un opción");
                        operation = Convert.ToInt32(Console.ReadLine());
                        Console.Clear();


                        switch (operation)
                        {
                            case 1:
                                Console.WriteLine("Registrar Alumno");

                                Console.WriteLine("Nombre");
                                names = Console.ReadLine();
                                Console.WriteLine("\n");

                                Console.WriteLine("Apellido");
                                surnames = Console.ReadLine();
                                Console.WriteLine("\n");

                                Console.WriteLine("Edad");
                                age = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("\n");
                                Console.WriteLine("Registro exitoso");

                                conexion.NuevoAlumno(names, surnames, age);
                                break;
                            case 2:
                                Console.WriteLine("Eliminar Alumno");

                                dt = conexion.Consultar();
                                conexion.All_st(dt);

                                Console.WriteLine("Matrícula");
                                tuition = Convert.ToInt32(Console.ReadLine());
                                Console.Clear();

                                Console.WriteLine("Alumno Seleccionado\n");
                                dt = conexion.Consultar(tuition);
                                conexion.Each_st(dt);
                                int confirm = 0;

                                while (confirm != 1 && confirm != 2)
                                {
                                    Console.Write("¿Estás seguro de continuar con el proceso?\n\n 1.Si\n 2.No\n\n");
                                    confirm = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("\n");

                                    switch (confirm)
                                    {
                                        case 1:
                                            conexion.EliminarAlumno(tuition);
                                            Console.WriteLine("Baja exitosa");
                                            Console.ReadKey();
                                            break;
                                        case 2:
                                            Console.WriteLine("Se canceló el proceso");
                                            Console.ReadKey();
                                            break;
                                        default:
                                            Console.WriteLine("Opción no valida");
                                            Console.ReadKey();
                                            break;
                                    }
                                }
                                break;
                            case 3:
                                Console.WriteLine("Actualizar datos del Alumno\n");

                                dt = conexion.Consultar();
                                conexion.All_st(dt);

                                Console.WriteLine("Matrícula");
                                tuition = Convert.ToInt32(Console.ReadLine());
                                Console.Clear();

                                int operacion = 1;

                                while (operacion == 1)
                                {
                                    Console.Clear();
                                    Console.WriteLine("Alumno Seleccionado\n");
                                    dt = conexion.Consultar(tuition);
                                    conexion.Each_st(dt);

                                    Console.Write("> Editar\n\n 1. Nombre\n 2. Apellido\n 3. Edad\n\n ~~Presione otra tecla para salir ~~\n Seleccionar: ");
                                    operation = Convert.ToInt32(Console.ReadLine());

                                    if (operation != 1 && operation != 2 && operation != 3)
                                    {
                                        operacion = 2;
                                        continue;
                                    }

                                    Console.Clear();

                                    switch (operation)
                                    {
                                        case 1:
                                            Console.WriteLine("~~Nuevo Valor~~\n");
                                            Console.Write("Nombre: ");
                                            names = Console.ReadLine();
                                            conexion.ActAlumno(tuition, names: names);
                                            Console.WriteLine("\nNuevo valor asignado satisfactoriamente");
                                            break;
                                        case 2:
                                            Console.WriteLine("~~Nuevo Valor~~\n");
                                            Console.Write("Apellido: ");
                                            surnames = Console.ReadLine();
                                            conexion.ActAlumno(tuition, surnames: surnames);
                                            Console.WriteLine("\nNuevo valor asignado satisfactoriamente");
                                            break;
                                        case 3:
                                            Console.WriteLine("~~Nuevo Valor~~\n");
                                            Console.Write("Edad: ");
                                            age = Convert.ToInt16(Console.ReadLine());
                                            conexion.ActAlumno(tuition, age: age);
                                            Console.WriteLine("\nNuevo valor asignado satisfactoriamente");
                                            break;
                                        default:
                                            break;
                                    }

                                    Console.Clear();
                                    Console.WriteLine("> || Opciones ||\n 1. Continuar editando\n 2. Terminar edicion");
                                    operacion = Convert.ToInt16(Console.ReadLine());
                                    Console.Clear();
                                }
                                break;
                            case 4:
                                Console.WriteLine("Consulta General\n");
                                dt = conexion.Consultar();
                                conexion.All_st(dt);
                                break;
                            case 5:
                                Console.WriteLine("Consulta Individual\n");
                                Console.Write("Matrícula: ");
                                tuition = Convert.ToInt32(Console.ReadLine());
                                dt = conexion.Consultar(tuition);
                                Console.WriteLine("\n");
                                conexion.Each_st(dt);
                                break;
                            case 6:
                                Console.WriteLine("Finalizar\n");
                                Console.Clear();
                                Console.WriteLine("Saliendo del menú de alumnos...");
                                break;
                            default:
                                Console.WriteLine("No se encontró la opción seleccionada");
                                break;
                        }
                        Console.Write("\nPresiona cualquier tecla para continuar");
                        Console.ReadKey();
                    }
                }
                else if (op1 == 2)
                {
                    int operation = 0;
                    int closeExecution = 6;

                    while (operation != closeExecution)
                    {
                        Console.Clear();
                        Console.WriteLine("   || Menú Maestros ||\n\n1. Registrar Maestro\n2. Eliminar Maestro\n3. Actualizar datos del Maestro\n4. Consulta general\n5. Consulta Individual (Requiere matrícula)\n6. Finalizar\n\nSeleccione un opción");
                        operation = Convert.ToInt32(Console.ReadLine());
                        Console.Clear();

                        switch (operation)
                        {
                            case 1:
                                Console.WriteLine("Registrar Maestro");

                                Console.WriteLine("Nombre");
                                names = Console.ReadLine();
                                Console.WriteLine("\n");

                                Console.WriteLine("Apellido Paterno");
                                surnames = Console.ReadLine();
                                Console.WriteLine("\n");

                                Console.WriteLine("Apellido Materno");
                                surnames2 = Console.ReadLine();
                                Console.WriteLine("\n");

                                Console.WriteLine("Cédula (9 caracteres)");
                                cedula = Console.ReadLine();
                                Console.WriteLine("\n");

                                Console.WriteLine("Numero de Empleado");
                                nEmpleado = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("\n");

                                Console.WriteLine("ID De La Carrera (4 dígitos)");
                                idCarrera = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("\n");
                                conexion_m.N_Maestro(names, surnames, surnames2, cedula, nEmpleado, idCarrera);

                                Console.WriteLine("Registro exitoso");
                                Console.ReadKey();

                                break;
                            case 2:
                                Console.WriteLine("Eliminar Maestro");

                                dt = conexion_m.Consultar();
                                conexion_m.All_m(dt);

                                Console.WriteLine("Matrícula");
                                tuition = Convert.ToInt32(Console.ReadLine());
                                Console.Clear();

                                Console.WriteLine("Maestro Seleccionado\n");
                                dt = conexion_m.Consultar(tuition);
                                conexion_m.Each_m(dt);

                                int confirm = 0;

                                while (confirm != 1 && confirm != 2)
                                {
                                    Console.Write("¿Estás seguro de continuar con el proceso?\n\n 1.Si\n 2.No\n\n");
                                    confirm = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("\n");

                                    switch (confirm)
                                    {
                                        case 1:
                                            conexion_m.E_Maestro(tuition);
                                            Console.WriteLine("Baja exitosa");
                                            Console.WriteLine("Presione enter para continuar");

                                            Console.ReadKey();
                                            break;
                                        case 2:
                                            Console.WriteLine("Se canceló el proceso");
                                            Console.WriteLine("Presione enter para continuar");

                                            Console.ReadKey();
                                            break;
                                        default:
                                            Console.WriteLine("Opción no valida");
                                            Console.WriteLine("Presione enter para continuar");
                                            Console.ReadKey();
                                            break;
                                    }

                                }
                                break;

                            case 3:
                                Console.WriteLine("Actualizar datos del Maestro\n");

                                dt = conexion_m.Consultar();
                                conexion_m.All_m(dt);

                                Console.WriteLine("Matrícula");
                                tuition = Convert.ToInt32(Console.ReadLine());

                                int operacion = 1;

                                while (operacion == 1)
                                {
                                    Console.Clear();
                                    Console.WriteLine("Maestro Seleccionado\n");
                                    dt = conexion_m.Consultar(tuition);
                                    conexion_m.Each_m(dt);

                                    Console.Write("> Editar\n\n 1. Nombre\n 2. Apellido Paterno\n 3. Apellido Materno\n 4. Carrera\n\n ~~Presione otra tecla para salir ~~\n Seleccionar: ");
                                    operation = Convert.ToInt32(Console.ReadLine());

                                    if (operation != 1 && operation != 2 && operation != 3 && operation != 4)
                                    {
                                        operacion = 2;
                                        continue;
                                    }

                                    Console.Clear();

                                    switch (operation)
                                    {
                                        case 1:
                                            Console.WriteLine("~~Nuevo Valor~~\n");
                                            Console.Write("Nombre: ");
                                            names = Console.ReadLine();
                                            conexion_m.ActMaestro(tuition, names: names);
                                            Console.WriteLine("\nNuevo valor asignado satisfactoriamente");
                                            break;
                                        case 2:
                                            Console.WriteLine("~~Nuevo Valor~~\n");
                                            Console.Write("Apellido Paterno: ");
                                            surnames = Console.ReadLine();
                                            conexion_m.ActMaestro(tuition, surname1: surnames);
                                            Console.WriteLine("\nNuevo valor asignado satisfactoriamente");
                                            break;
                                        case 3:
                                            Console.WriteLine("~~Nuevo Valor~~\n");
                                            Console.Write("Apellido Materno: ");
                                            surnames2 = Console.ReadLine();
                                            conexion_m.ActMaestro(tuition, surname2: surnames2);
                                            Console.WriteLine("\nNuevo valor asignado satisfactoriamente");
                                            break;
                                        case 4:
                                            Console.WriteLine("~~Nuevo Valor~~\n");
                                            Console.Write("Carrera: ");
                                            idCarrera = Convert.ToInt32(Console.ReadLine());
                                            conexion_m.ActMaestro(tuition, idc: idCarrera);
                                            Console.WriteLine("\nNuevo valor asignado satisfactoriamente");
                                            break;
                                        default:
                                            break;
                                    }

                                    Console.Clear();
                                    Console.WriteLine("> || Opciones ||\n 1. Continuar editando\n 2. Terminar edición");
                                    operacion = Convert.ToInt16(Console.ReadLine());
                                    Console.Clear();
                                }
                                break;
                            case 4:
                                Console.WriteLine("Consulta General\n");
                                dt = conexion_m.Consultar();
                                conexion_m.All_m(dt);
                                Console.WriteLine("\nPresione enter para continuar");
                                Console.ReadKey();
                                break;
                            case 5:
                                Console.WriteLine("Consulta Individual\n");
                                Console.Write("Matrícula: ");
                                tuition = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("\n");
                                dt = conexion_m.Consultar(tuition);
                                conexion_m.Each_m(dt);
                                Console.WriteLine("\nPresione enter para continuar");
                                Console.ReadKey();
                                break;
                            case 6:
                                Console.WriteLine("Finalizar\n");
                                Console.Clear();
                                Console.WriteLine("Saliendo del menú de maestros...");
                                Console.ReadKey();
                                break;
                        }
                    }
                }
                else if (op1 == 3)
                {
                    int operation = 0;
                    int closeExecution = 6;

                    while (operation != closeExecution)
                    {
                        Console.Clear();
                        Console.WriteLine("   || Menú Carrera ||\n\n1. Registrar Carrera\n2. Eliminar Carrera\n3. Actualizar datos de la Carrera\n4. Consulta general\n5. Consulta Individual (Requiere matrícula)\n6. Finalizar\n\nSeleccione un opción");
                        operation = Convert.ToInt32(Console.ReadLine());
                        Console.Clear();

                        switch (operation)
                        {
                            case 1:
                                Console.WriteLine("Registrar Carrera");

                                Console.WriteLine("Nombre");
                                names = Console.ReadLine();
                                Console.WriteLine("\n");

                                Console.WriteLine("Descripción de la carrera");
                                des = Console.ReadLine();
                                Console.WriteLine("\n");

                                conexion_c.N_Carrera(names, des);

                                Console.WriteLine("Registro exitoso");
                                Console.ReadKey();

                                break;
                            case 2:
                                Console.WriteLine("Eliminar Carrera");

                                dt = conexion_c.Consultar();
                                conexion_c.All_c(dt);

                                Console.WriteLine("Matrícula");
                                tuition = Convert.ToInt32(Console.ReadLine());
                                Console.Clear();

                                Console.WriteLine("Carrera Seleccionada\n");
                                dt = conexion_c.Consultar();
                                conexion_c.Each_c(dt);

                                int confirm = 0;

                                while (confirm != 1 && confirm != 2)
                                {
                                    Console.Write("¿Estás seguro de continuar con el proceso?\n\n 1.Si\n 2.No\n\n");
                                    confirm = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("\n");

                                    switch (confirm)
                                    {
                                        case 1:
                                            conexion_c.E_Carrera(tuition);
                                            Console.WriteLine("Baja exitosa");
                                            Console.WriteLine("Presione enter para continuar");

                                            Console.ReadKey();
                                            break;
                                        case 2:
                                            Console.WriteLine("Se canceló el proceso");
                                            Console.WriteLine("Presione enter para continuar");

                                            Console.ReadKey();
                                            break;
                                        default:
                                            Console.WriteLine("Opción no valida");
                                            Console.WriteLine("Presione enter para continuar");
                                            Console.ReadKey();
                                            break;
                                    }

                                }

                                break;
                            case 3:
                                Console.WriteLine("Actualizar datos de Carrera\n");

                                dt = conexion_c.Consultar();
                                conexion_c.All_c(dt);

                                Console.WriteLine("Matrícula");
                                tuition = Convert.ToInt32(Console.ReadLine());

                                int operacion = 1;

                                while (operacion == 1)
                                {
                                    Console.Clear();
                                    Console.WriteLine("Carrera Seleccionada\n");
                                    dt = conexion_c.Consultar(tuition);
                                    conexion_c.Each_c(dt);

                                    Console.Write("> Editar\n\n 1. Nombre\n 2. Descripción\n\n ~~Presione otra tecla para salir ~~\n Seleccionar: ");
                                    operation = Convert.ToInt32(Console.ReadLine());

                                    if (operation != 1 && operation != 2)
                                    {
                                        operacion = 2;
                                        continue;
                                    }

                                    Console.Clear();

                                    switch (operation)
                                    {
                                        case 1:
                                            Console.WriteLine("~~Nuevo Valor~~\n");
                                            Console.Write("Nombre: ");
                                            names = Console.ReadLine();
                                            conexion_c.UCarrera(tuition, name: names);
                                            Console.WriteLine("\nNuevo valor asignado satisfactoriamente");
                                            break;
                                        case 2:
                                            Console.WriteLine("~~Nuevo Valor~~\n");
                                            Console.Write("Descripción de Carrera: ");
                                            des = Console.ReadLine();
                                            conexion_c.UCarrera(tuition, desc: des);
                                            Console.WriteLine("\nNuevo valor asignado satisfactoriamente");
                                            break;
                                        default:
                                            break;
                                    }

                                    Console.Clear();
                                    Console.WriteLine("> || Opciones ||\n 1. Continuar editando\n 2. Terminar edición");
                                    operacion = Convert.ToInt16(Console.ReadLine());
                                    Console.Clear();
                                }
                                    break;
                            case 4:
                                Console.WriteLine("Consulta General\n");
                                dt = conexion_c.Consultar();
                                conexion_c.All_c(dt);
                                Console.WriteLine("\nPresione enter para continuar");
                                Console.ReadKey();
                                break;
                            case 5:
                                Console.WriteLine("Consulta Individual\n");
                                Console.Write("Matrícula: ");
                                tuition = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("\n");
                                dt = conexion_c.Consultar(tuition);
                                conexion_c.Each_c(dt);
                                Console.WriteLine("\nPresione enter para continuar");
                                Console.ReadKey();
                                break;
                            case 6:
                                Console.WriteLine("Finalizar\n");
                                Console.Clear();
                                Console.WriteLine("Saliendo del menú de Carrera...");
                                Console.ReadKey();
                                break;
                        }
                    }
                }
            }
            Console.Clear();
            Console.WriteLine("Cerrando el sistema...");
            Console.WriteLine("Presione enter para continuar");
            Console.ReadKey();
        }
    }
}