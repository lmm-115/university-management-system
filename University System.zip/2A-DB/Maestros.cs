﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;

namespace Universidad
{
    internal class Maestros
    {
        Connection con = new Connection();

        public void N_Maestro(string names, string surname, string surname2, string cedula, int nE, int carrera)
        {
            try
            {
                con.Conectar();

                string query = "INSERT INTO Maestro VALUES (@n, @s1, @s2, @nemp, @ced, @idc)";
                SqlCommand cmd = new SqlCommand(query, con.Url());

                cmd.Parameters.Add("@n", SqlDbType.VarChar, 50).Value = names;
                cmd.Parameters.Add("@s1", SqlDbType.VarChar, 50).Value = surname;
                cmd.Parameters.Add("@s2", SqlDbType.VarChar, 50).Value = surname2;
                cmd.Parameters.Add("@ced", SqlDbType.VarChar, 9).Value = cedula;
                cmd.Parameters.Add("@nemp", SqlDbType.Int, 2).Value = nE;
                cmd.Parameters.Add("@idc", SqlDbType.Int, 4).Value = carrera;
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }
        }

        public void E_Maestro(int tuition)
        {
            try
            {
                con.Conectar();

                string query = "DELETE FROM Maestro WHERE IDMaestro = @id";
                SqlCommand cmd = new SqlCommand(query, con.Url());

                cmd.Parameters.Add("@id", SqlDbType.Int, 4).Value = tuition;
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }
        }

        public void ActMaestro(int tuition, [Optional] string names, [Optional] string surname1, [Optional] string surname2, [Optional] int idc)
        {
            // update Maestro set Nombre = 'Carlos' where IDMaestro = 1006;

            string queryNames = "UPDATE Maestro SET Nombre = @names WHERE IDMaestro = @tuition";
            string queryS1 = "UPDATE Maestro SET AP = @surname1 WHERE IDMaestro = @tuition";
            string queryS2 = "UPDATE Maestro SET AM = @surname2 WHERE IDMaestro = @tuition";
            string queryCareer = "UPDATE Maestro SET IDCarrera = @idc where IDMaestro = @tuition";

            try
            {
                con.Conectar();

                if (!string.IsNullOrWhiteSpace(names))
                {
                    SqlCommand cmd = new SqlCommand(queryNames, con.Url());
                    cmd.Parameters.Add("@names", SqlDbType.VarChar, 50).Value = names;
                    cmd.Parameters.Add("@tuition", SqlDbType.Int, 4).Value = tuition;
                    cmd.ExecuteNonQuery();
                }

                if (!string.IsNullOrWhiteSpace(surname1))
                {
                    SqlCommand cmd = new SqlCommand(queryS1, con.Url());
                    cmd.Parameters.Add("@surname1", SqlDbType.VarChar, 50).Value = surname1;
                    cmd.Parameters.Add("@tuition", SqlDbType.Int, 4).Value = tuition;
                    cmd.ExecuteNonQuery();
                }

                if (!string.IsNullOrWhiteSpace(surname2))
                {
                    SqlCommand cmd = new SqlCommand(queryS2, con.Url());
                    cmd.Parameters.Add("@surname2", SqlDbType.VarChar, 50).Value = surname2;
                    cmd.Parameters.Add("@tuition", SqlDbType.Int, 4).Value = tuition;
                    cmd.ExecuteNonQuery();
                }

                if (idc > 0)
                {
                    SqlCommand cmd = new SqlCommand(queryCareer, con.Url());
                    cmd.Parameters.Add("@idc", SqlDbType.Int, 4).Value = idc;
                    cmd.Parameters.Add("@tuition", SqlDbType.Int, 4).Value = tuition;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }
        }

        public DataTable Consultar(int? tuition = null)
        {
            DataTable dt = new DataTable();

            try
            {
                con.Conectar();

                string query = tuition == null ? "SELECT * FROM Maestro" : "SELECT * FROM Maestro WHERE IDMaestro=@tuition";
                SqlCommand cmd = new SqlCommand(query, con.Url());

                if (tuition != null) cmd.Parameters.Add("@tuition", SqlDbType.Int, 4).Value = tuition;

                SqlDataAdapter data = new SqlDataAdapter(cmd);
                data.Fill(dt);
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }

            return dt;
        }

        public void All_m(DataTable dataTable)
        {
            int dataTableLength = dataTable.Rows.Count;
            bool hasData = dataTableLength > 0;

            if (hasData)
            {
                for (int i = 0; i < dataTableLength; i++)
                {
                    Console.WriteLine("  <> Matricula           →   {0}", Convert.ToInt32(dataTable.Rows[i][0].ToString()));
                    Console.WriteLine("  <> Nombres             →   {0}", dataTable.Rows[i][1].ToString());
                    Console.WriteLine("  <> Apellido Paterno    →   {0}", dataTable.Rows[i][2].ToString());
                    Console.WriteLine("  <> Apellido Materno    →   {0}", dataTable.Rows[i][3].ToString());
                    Console.WriteLine("  <> Número de Empleado  →   {0}", dataTable.Rows[i][4].ToString());
                    Console.WriteLine("  <> Cédula              →   {0}", dataTable.Rows[i][5].ToString());
                    Console.WriteLine("  <> Carrera             →   {0}", Convert.ToInt32(dataTable.Rows[i][6].ToString()));
                    Console.Write("\n");
                }
            }
        }

        public void Each_m(DataTable dataTable)
        {
            int dataTableLength = dataTable.Rows.Count;
            bool hasData = dataTableLength > 0;

            if (hasData)
            {
                Console.WriteLine("  <> Matricula           →   {0}", Convert.ToInt32(dataTable.Rows[0][0].ToString()));
                Console.WriteLine("  <> Nombres             →   {0}", dataTable.Rows[0][1].ToString());
                Console.WriteLine("  <> Apellido Paterno    →   {0}", dataTable.Rows[0][2].ToString());
                Console.WriteLine("  <> Apellido Materno    →   {0}", dataTable.Rows[0][3].ToString());
                Console.WriteLine("  <> Número de Empleado  →   {0}", dataTable.Rows[0][4].ToString());
                Console.WriteLine("  <> Cédula              →   {0}", dataTable.Rows[0][5].ToString());
                Console.WriteLine("  <> Carrera             →   {0}", Convert.ToInt32(dataTable.Rows[0][6].ToString()));
                Console.Write("\n");
            }
        }
    }
}