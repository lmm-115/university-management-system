﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.CompilerServices;

namespace Universidad
{
    internal class Carrera
    {
        Connection con = new Connection();

        public void N_Carrera(string name, string desc)
        {
            try
            {
                con.Conectar();
                string query = "insert into Carrera values (@n, @d)";
                SqlCommand cmd = new SqlCommand(query, con.Url());

                cmd.Parameters.Add("@n", SqlDbType.VarChar, 50).Value = name;
                cmd.Parameters.Add("@d", SqlDbType.VarChar, 50).Value = desc;
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }
        }
        
        public void E_Carrera( int id)
        {
            try
            {
                con.Conectar();

                string query = "delete from Carrera where IDCarrera = @id";
                SqlCommand cmd = new SqlCommand(query, con.Url());

                cmd.Parameters.Add("@id", SqlDbType.Int, 4).Value = id;
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }
        }

        public void UCarrera(int id, [Optional] string name, [Optional] string desc)
        {
            string qn = "update Carrera set Nombre = @n where IDCarrera = @i";
            string qd = "update Carrera set Descripcion = @d where IDCarrera = @i";

            try
            {
                con.Conectar();
                
                if (!string.IsNullOrWhiteSpace(name))
                {
                    SqlCommand cmd = new SqlCommand(qn, con.Url());
                    cmd.Parameters.Add("@n", SqlDbType.VarChar, 50).Value = name;
                    cmd.Parameters.Add("@i", SqlDbType.Int, 4).Value = id;
                    cmd.ExecuteNonQuery();
                }
                if (!string.IsNullOrWhiteSpace(desc))
                {
                    SqlCommand cmd = new SqlCommand(qd, con.Url());
                    cmd.Parameters.Add("@d", SqlDbType.VarChar, 50).Value = desc;
                    cmd.Parameters.Add("@i", SqlDbType.Int, 4).Value = id;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }
        }

        public DataTable Consultar(int? tuition = null)
        {
            DataTable dt = new DataTable();

            try
            {
                con.Conectar();

                string query = tuition == null ? "SELECT * FROM Carrera" : "SELECT * FROM Carrera WHERE IDCarrera=@id";
                SqlCommand cmd = new SqlCommand(query, con.Url());

                if (tuition != null) cmd.Parameters.Add("@id", SqlDbType.Int, 4).Value = tuition;

                SqlDataAdapter data = new SqlDataAdapter(cmd);
                data.Fill(dt);
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }

            return dt;
        }

        public void All_c(DataTable dataTable)
        {
            int dataTableLength = dataTable.Rows.Count;
            bool hasData = dataTableLength > 0;

            if (hasData)
            {
                for (int i = 0; i < dataTableLength; i++)
                {
                    Console.WriteLine("  <> Matrícula    →   {0}", Convert.ToInt32(dataTable.Rows[i][0].ToString()));
                    Console.WriteLine("  <> Nombre       →   {0}", dataTable.Rows[i][1].ToString());
                    Console.WriteLine("  <> Descripción  →   {0}", dataTable.Rows[i][2].ToString());
                    Console.Write("\n");
                }
            }
        }

        public void Each_c(DataTable dataTable)
        {
            int dataTableLength = dataTable.Rows.Count;
            bool hasData = dataTableLength > 0;

            if (hasData)
            {
                Console.WriteLine("  <> Matrícula    →   {0}", Convert.ToInt32(dataTable.Rows[0][0].ToString()));
                Console.WriteLine("  <> Nombre       →   {0}", dataTable.Rows[0][1].ToString());
                Console.WriteLine("  <> Descripción  →   {0}", dataTable.Rows[0][2].ToString());
                Console.Write("\n");
            }
        }
    }
}