﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;

namespace Universidad
{
    internal class Connection
    {
        private readonly SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-5E8A2G9; Initial Catalog=TIADSM2A; Integrated Security=true");

        public void Conectar()
        {
            try
            {
                conexion.Open();
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
        }
        public void Desconectar()
        {
            conexion.Close();
        }
        public SqlConnection Url()
        {
            return conexion;
        }
    }
}