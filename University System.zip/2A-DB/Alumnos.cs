﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;

namespace Universidad
{
    internal class Alumnos
    {
        Connection con = new Connection();
        public void NuevoAlumno(string names, string surnames, int age)
        {
            try
            {
                con.Conectar();

                string query = "INSERT INTO Alumnos VALUES (@name, @surname, @age)";
                SqlCommand cmd = new SqlCommand(query, con.Url());

                cmd.Parameters.Add("@name", SqlDbType.VarChar, 50).Value = names;
                cmd.Parameters.Add("@surname", SqlDbType.VarChar, 50).Value = surnames;
                cmd.Parameters.Add("@age", SqlDbType.Int, 3).Value = age;
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }
        }

        public void EliminarAlumno(int tuition)
        {
            try
            {
                con.Conectar();

                string query = "DELETE FROM Alumnos WHERE tuition = @tuition";
                SqlCommand cmd = new SqlCommand(query, con.Url());

                cmd.Parameters.Add("@tuition", SqlDbType.Int, 4).Value = tuition;
                cmd.ExecuteNonQuery();
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }
        }

        public void ActAlumno(int tuition, [Optional] string names, [Optional] string surnames, [Optional] int age)
        {
            string queryNames = "UPDATE Alumnos SET names=@names WHERE tuition=@tuition";
            string querySurnames = "UPDATE Alumnos SET surname=@surname WHERE tuition=@tuition";
            string queryAge = "UPDATE Alumnos SET age=@age WHERE tuition=@tuition";

            try
            {
                con.Conectar();

                if (!string.IsNullOrWhiteSpace(names))
                {
                    SqlCommand cmd = new SqlCommand(queryNames, con.Url());
                    cmd.Parameters.Add("@names", SqlDbType.VarChar, 50).Value = names;
                    cmd.Parameters.Add("@tuition", SqlDbType.Int, 4).Value = tuition;
                    cmd.ExecuteNonQuery();
                }

                if (!string.IsNullOrWhiteSpace(surnames))
                {
                    SqlCommand cmd = new SqlCommand(querySurnames, con.Url());
                    cmd.Parameters.Add("@surname", SqlDbType.VarChar, 50).Value = surnames;
                    cmd.Parameters.Add("@tuition", SqlDbType.Int, 4).Value = tuition;
                    cmd.ExecuteNonQuery();
                }

                if (age > 0)
                {
                    SqlCommand cmd = new SqlCommand(queryAge, con.Url());
                    cmd.Parameters.Add("@age", SqlDbType.Int, 3).Value = age;
                    cmd.Parameters.Add("@tuition", SqlDbType.Int, 4).Value = tuition;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }
        }

        public DataTable Consultar(int? tuition = null)
        {
            DataTable dt = new DataTable();

            try
            {
                con.Conectar();
                string query = tuition == null ? "SELECT * FROM Alumnos" : "SELECT * FROM Alumnos WHERE tuition=@tuition";
                SqlCommand cmd = new SqlCommand(query, con.Url());

                if (tuition != null) cmd.Parameters.Add("@tuition", SqlDbType.Int, 4).Value = tuition;

                SqlDataAdapter data = new SqlDataAdapter(cmd);
                data.Fill(dt);
            }
            catch (Exception err)
            {
                Console.WriteLine(err.Message);
            }
            finally
            {
                con.Desconectar();
            }

            return dt;
        }

        public void All_st(DataTable dataTable)
        {
            int dataTableLength = dataTable.Rows.Count;
            bool hasData = dataTableLength > 0;

            if (hasData)
            {
                for (int i = 0; i < dataTableLength; i++)
                {
                    Console.WriteLine("  <> Matricula    →   {0}", Convert.ToInt32(dataTable.Rows[i][0].ToString()));
                    Console.WriteLine("  <> Nombres      →   {0}", dataTable.Rows[i][1].ToString());
                    Console.WriteLine("  <> Apellidos    →   {0}", dataTable.Rows[i][2].ToString());
                    Console.WriteLine("  <> Edad         →   {0}", Convert.ToInt32(dataTable.Rows[i][3].ToString()));
                    Console.Write("\n");
                }
            }
        }

        public void Each_st(DataTable dataTable)
        {
            int dataTableLength = dataTable.Rows.Count;
            bool hasData = dataTableLength > 0;

            if (hasData)
            {
                Console.WriteLine("  <> Matricula    →   {0}", Convert.ToInt32(dataTable.Rows[0][0].ToString()));
                Console.WriteLine("  <> Nombres      →   {0}", dataTable.Rows[0][1].ToString());
                Console.WriteLine("  <> Apellidos    →   {0}", dataTable.Rows[0][2].ToString());
                Console.WriteLine("  <> Edad         →   {0}", Convert.ToInt32(dataTable.Rows[0][3].ToString()));
                Console.Write("\n");
            }
        }
    }
}